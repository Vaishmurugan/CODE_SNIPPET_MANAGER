import java.util.*;
import java.text.SimpleDateFormat;

class CodeSnippet {
    private String title;
    private String language;
    private String code;
    private String timestamp;
    private boolean isFavorite;

    public CodeSnippet(String title, String language, String code) {
        this.title = title;
        this.language = language;
        this.code = code;
        this.timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        this.isFavorite = false;
    }

    public String getTitle() {
        return title;
    }

    public String getLanguage() {
        return language;
    }

    public String getCode() {
        return code;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }

    @Override
    public String toString() {
        return "Title: " + title +
               "\nLanguage: " + language +
               "\nCode:\n" + code +
               "\nTimestamp: " + timestamp +
               "\nFavorite: " + (isFavorite ? "⭐ Yes" : "No");
    }
}

class SnippetManager {
    private List<CodeSnippet> snippets;

    public SnippetManager() {
        snippets = new ArrayList<>();
    }

    public void addSnippet(String title, String language, String code) {
        snippets.add(new CodeSnippet(title, language, code));
    }

    public void deleteSnippet(String title) {
        Iterator<CodeSnippet> iterator = snippets.iterator();
        while (iterator.hasNext()) {
            CodeSnippet snippet = iterator.next();
            if (snippet.getTitle().equalsIgnoreCase(title)) {
                iterator.remove();
                System.out.println("Snippet '" + title + "' deleted successfully.");
                return;
            }
        }
        System.out.println("Snippet not found.");
    }

    public void markFavorite(String title) {
        for (CodeSnippet snippet : snippets) {
            if (snippet.getTitle().equalsIgnoreCase(title)) {
                snippet.setFavorite(true);
                System.out.println("Snippet '" + title + "' marked as favorite. ⭐");
                return;
            }
        }
        System.out.println("Snippet not found.");
    }

    public List<CodeSnippet> getSnippetsByLanguage(String language) {
        List<CodeSnippet> result = new ArrayList<>();
        for (CodeSnippet snippet : snippets) {
            if (snippet.getLanguage().equalsIgnoreCase(language)) {
                result.add(snippet);
            }
        }
        return result;
    }

    public void displayAllSnippets() {
        if (snippets.isEmpty()) {
            System.out.println("No snippets available.");
        } else {
            for (CodeSnippet snippet : snippets) {
                System.out.println(snippet);
                System.out.println("---------------------------");
            }
        }
    }

    public void displayFavorites() {
        boolean hasFavorites = false;
        for (CodeSnippet snippet : snippets) {
            if (snippet.isFavorite()) {
                System.out.println(snippet);
                System.out.println("---------------------------");
                hasFavorites = true;
            }
        }
        if (!hasFavorites) {
            System.out.println("No favorite snippets yet.");
        }
    }
}

public class CodeSnippetManager {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SnippetManager manager = new SnippetManager();

        while (true) {
            System.out.println("\n1. Add Snippet");
            System.out.println("2. View Snippets by Language");
            System.out.println("3. View All Snippets");
            System.out.println("4. Delete Snippet");
            System.out.println("5. Mark Snippet as Favorite");
            System.out.println("6. View Favorite Snippets");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter language: ");
                    String language = scanner.nextLine();
                    System.out.print("Enter code snippet: ");
                    String code = scanner.nextLine();
                    manager.addSnippet(title, language, code);
                    System.out.println("Snippet added successfully!");
                    break;

                case 2:
                    System.out.print("Enter language to filter: ");
                    String filterLanguage = scanner.nextLine();
                    List<CodeSnippet> snippets = manager.getSnippetsByLanguage(filterLanguage);
                    if (snippets.isEmpty()) {
                        System.out.println("No snippets found for this language.");
                    } else {
                        for (CodeSnippet snippet : snippets) {
                            System.out.println(snippet);
                            System.out.println("---------------------------");
                        }
                    }
                    break;

                case 3:
                    manager.displayAllSnippets();
                    break;

                case 4:
                    System.out.print("Enter title of the snippet to delete: ");
                    String deleteTitle = scanner.nextLine();
                    manager.deleteSnippet(deleteTitle);
                    break;

                case 5:
                    System.out.print("Enter title of the snippet to mark as favorite: ");
                    String favoriteTitle = scanner.nextLine();
                    manager.markFavorite(favoriteTitle);
                    break;

                case 6:
                    manager.displayFavorites();
                    break;

                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
